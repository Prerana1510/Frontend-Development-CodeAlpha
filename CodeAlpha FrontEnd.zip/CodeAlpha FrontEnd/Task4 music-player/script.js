let songs = [
    {
        title: "Song 1",
        artist: "Artist 1",
        src: "songs/song 1.mp3",
        cover: "cover/song 1.jpg"
    },
    {
        title: "Song 2",
        artist: "Artist 2",
        src: "songs/song 2.mp3",
        cover: "cover/song 2.jpg"
    },
    {
        title: "Song 3",
        artist: "Artist 3",
        src: "songs/song 3.mp3",
        cover: "cover/song 3.jpg"
    }
];

let index = 0;
let audio = document.getElementById("audio");

function loadSong(i) {
    audio.src = songs[i].src;
    document.getElementById("title").innerText = songs[i].title;
    document.getElementById("artist").innerText = songs[i].artist;
    document.getElementById("cover").src = songs[i].cover;   // IMAGE SET HERE
}

loadSong(index);

document.getElementById("play").onclick = () => {
    if (audio.paused) audio.play();
    else audio.pause();
};

document.getElementById("next").onclick = () => {
    index = (index + 1) % songs.length;
    loadSong(index);
    audio.play();
};

document.getElementById("prev").onclick = () => {
    index = (index - 1 + songs.length) % songs.length;
    loadSong(index);
    audio.play();
};

audio.addEventListener("timeupdate", () => {
    document.getElementById("progress").value =
        (audio.currentTime / audio.duration) * 100;
});

document.getElementById("progress").onchange = (e) => {
    audio.currentTime = (e.target.value * audio.duration) / 100;
};

document.getElementById("volume").oninput = (e) => {
    audio.volume = e.target.value;
};

audio.addEventListener("ended", () => {
    document.getElementById("next").click();
});

// BACKGROUND AUTO CHANGE
const bg = document.getElementById("bg");

function changeBackground() {
    const color = "hsl(" + Math.floor(Math.random() * 360) + ", 70%, 50%)";
    bg.style.background = color;
    bg.style.transition = "background 1s ease";
}

changeBackground();
setInterval(changeBackground, 10000);
