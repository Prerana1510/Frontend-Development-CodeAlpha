const display = document.getElementById('display');
const historyList = document.getElementById('historyList');
let memory = 0;

// Keyboard support
document.addEventListener('keydown', (e) => {
  if ((e.key >= '0' && e.key <= '9') || ['+', '-', '*', '/', '.', '%'].includes(e.key)) {
    appendValue(e.key);
  } else if (e.key === 'Enter') {
    calculate();
  } else if (e.key === 'Backspace') {
    backspace();
  } else if (e.key.toLowerCase() === 'c') {
    clearDisplay();
  }
});

function appendValue(val) {
  display.value += val;
}

function clearDisplay() {
  display.value = '';
}

function backspace() {
  display.value = display.value.slice(0, -1);
}

function plusMinus() {
  if(display.value) {
    if(display.value.startsWith('-')) {
      display.value = display.value.slice(1);
    } else {
      display.value = '-' + display.value;
    }
  }
}

function square() {
  if(display.value) {
    display.value = Math.pow(parseFloat(display.value), 2);
    addHistory(display.value);
  }
}

function squareRoot() {
  if(display.value) {
    display.value = Math.sqrt(parseFloat(display.value));
    addHistory(display.value);
  }
}

function calculate() {
  try {
    if(display.value.trim() === '') return;
    let result = eval(display.value);
    addHistory(`${display.value} = ${result}`);
    display.value = result;
  } catch {
    display.value = 'Error';
    setTimeout(() => clearDisplay(), 1000);
  }
}

function addHistory(entry) {
  const li = document.createElement('li');
  li.textContent = entry;
  historyList.prepend(li);
}

// Dark Mode Toggle
const toggleThemeBtn = document.getElementById('toggleTheme');
toggleThemeBtn.addEventListener('click', () => {
  document.body.classList.toggle('dark');
  toggleThemeBtn.textContent = document.body.classList.contains('dark') ? '☀️' : '🌙';
});
